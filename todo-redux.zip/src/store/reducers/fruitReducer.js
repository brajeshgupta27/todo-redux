import { ADD_ITEM, DELETE_ITEM } from "../constants";

const initialState={
    fruits:[]
}

const fruitReducer = (state = initialState, {type, payload}) =>{
    switch(type){
        case ADD_ITEM:
            return {
                ...state,
                fruits:[...state.fruits, payload]
            }

            case DELETE_ITEM:
                return {
                    ...state,
                    fruits:state.fruits.filter(i=>i.id!==payload)
                }
            

        default:
            return state
    }
}

export default fruitReducer;
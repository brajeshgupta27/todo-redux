import {combineReducers} from 'redux';
import fruitReducer from "./fruitReducer";

const rootReducer = combineReducers({
    fruitReducer
})

export default  rootReducer;
import { ADD_ITEM, DELETE_ITEM } from "../constants";

export const addFruit = (fruit) => {
  return {
    type: ADD_ITEM,
    payload: fruit
  };
};

export const removeFruit = (id) => {
  return {
    type: DELETE_ITEM,
    payload: id,
  };
};

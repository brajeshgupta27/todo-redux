import React from 'react'
import Fruits from './components/Fruits'
import './App.css'

const App = () => {
  return (
    <div className="App">
     <Fruits/>
    </div>
  )
}

export default App

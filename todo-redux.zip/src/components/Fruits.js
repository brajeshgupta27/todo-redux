import React, { useEffect, useState } from 'react';
import { addFruit, removeFruit } from '../store/actions';
import { useDispatch, useSelector } from 'react-redux';
import uuid from 'react-uuid';

const Fruits = () => {
    const [fruit, setFruit] = useState({id:'',fruit:''});
    const [basket, setBasket] = useState([]);
    const dispatch = useDispatch();
    const {fruitReducer:{fruits}} = useSelector(state=>state);
    console.log(basket)

    const addFruitHandler = (e) =>{
        const singleFruit = {id:uuid(),fruit:e.target.value};
        setFruit(singleFruit)
    };

    const addToBasket = (e) =>{
        e.preventDefault();
        dispatch(addFruit(fruit));
        setFruit({id:'',fruit:''})
    }

    useEffect(()=>{
        setBasket(fruits)
    },[fruits]);

    const removeFruitHandler = (id) =>{
        dispatch(removeFruit(id))
    }
    

    return (
        <div className="container">
            <form onSubmit = {addToBasket} className="input-group">
                <input type='text' placeholder='Enter Fruit...' value={fruit.fruit} onChange={addFruitHandler}/>
                <button type='submit' disabled={!fruit.fruit}>Add Fruit</button>
            </form>

            <p>{
                // basket.length>0 && 'Fruit List'
                basket.length>0?"Fruit List":"No fruit added"
            }</p>

            <div className="list">
               {
                    basket.map((i,index) =>(
                        <div key={i.id} className="s-item">
                            <div className="item-name">{index + 1}.&nbsp;&nbsp;{i.fruit}</div>
                            <button className="close" onClick={()=>removeFruitHandler(i.id)}>remove</button>    
                        </div>
                    ))
               }
            </div>


        </div>
    )
}

export default Fruits
